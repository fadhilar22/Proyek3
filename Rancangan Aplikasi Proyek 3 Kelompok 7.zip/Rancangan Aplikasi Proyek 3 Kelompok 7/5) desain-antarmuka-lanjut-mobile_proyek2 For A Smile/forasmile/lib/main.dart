import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Forasmile'),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset('assets/img/forasmile1.png'),
            Container(
              margin: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Text(
                    'Penyaluran Dana Sedekah',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Image.asset('assets/img/content1.png', width: 150),
                          const SizedBox(height: 10),
                          const Text('Berbagi Makanan', textAlign: TextAlign.center),
                        ],
                      ),
                      Column(
                        children: [
                          Image.asset('assets/img/content2.png', width: 150),
                          const SizedBox(height: 10),
                          const Text('Santunan Anak Yatim/Piatu', textAlign: TextAlign.center),
                        ],
                      ),
                      Column(
                        children: [
                          Image.asset('assets/img/content3.png', width: 150),
                          const SizedBox(height: 10),
                          const Text('Bazaar Gratis', textAlign: TextAlign.center),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.orange,
        child: SizedBox(
          height: 100,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.mail),
                    onPressed: () {},
                  ),
                  const Text('Forasmile@gmail.com'),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: Icon(Icons.instagram),
                    onPressed: () {},
                  ),
                  const Text('@for_a_smile__'),
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.phone),
                    onPressed: () {},
                  ),
                  const Text('0896-3665-8471'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
