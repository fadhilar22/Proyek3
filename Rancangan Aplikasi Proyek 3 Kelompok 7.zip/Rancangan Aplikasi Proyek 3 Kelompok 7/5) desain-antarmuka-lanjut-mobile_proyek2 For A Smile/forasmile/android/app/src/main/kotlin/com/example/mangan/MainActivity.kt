package com.example.mangan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
